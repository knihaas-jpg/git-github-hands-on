from django.test import TestCase
from django.urls import reverse

from cms.models import Page


class CmsViewTests(TestCase):
    def test_create_edit_and_view_page(self):
        resp = self.client.post(reverse("cms:page_create"), {"title": "Home", "slug": "home", "content": "<h1>Hi</h1>"})
        self.assertRedirects(resp, reverse("cms:page_detail", args=["home"]))
        self.client.post(reverse("cms:page_edit", args=["home"]), {"title": "Home", "slug": "home", "content": "<h1>New</h1>"})
        self.assertEqual(Page.objects.get(slug="home").content, "<h1>New</h1>")

    def test_list_and_detail(self):
        Page.objects.create(title="Docs", slug="docs", content="<p>x</p>")
        self.assertContains(self.client.get(reverse("cms:page_list")), "Docs")
        self.assertContains(self.client.get(reverse("cms:page_detail", args=["docs"])), "Run accessibility audit")

    def test_page_html_is_shown_escaped(self):
        Page.objects.create(title="X", slug="x", content="<script>alert(1)</script>")
        self.assertNotContains(self.client.get(reverse("cms:page_detail", args=["x"])), "<script>alert(1)</script>")

    def test_unknown_page_404(self):
        self.assertEqual(self.client.get(reverse("cms:page_detail", args=["nope"])).status_code, 404)
