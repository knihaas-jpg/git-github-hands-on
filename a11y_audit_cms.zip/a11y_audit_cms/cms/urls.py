from django.urls import path

from . import views

app_name = "cms"
urlpatterns = [
    path("", views.page_list, name="page_list"),
    path("new/", views.page_create, name="page_create"),
    path("<slug:slug>/", views.page_detail, name="page_detail"),
    path("<slug:slug>/edit/", views.page_edit, name="page_edit"),
]
