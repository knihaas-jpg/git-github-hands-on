from django.core.management.base import BaseCommand

from cms.models import Page

BAD = """<h1>Our Company</h1>
<h3>Services</h3>
<img src="team.jpg">
<p style="color:#999">Contact us for a quote.</p>
<a href="/more">click here</a>
<div onclick="openMenu()">Menu</div>
<input type="text" placeholder="Email">
<button><svg></svg></button>
"""

GOOD = """<h1>Accessible Page</h1>
<h2>Services</h2>
<img src="team.jpg" alt="Our team at the 2026 open-source meetup">
<p>Read the <a href="/report">2026 accessibility report</a>.</p>
<label for="email">Email</label>
<input id="email" type="email">
<button type="submit">Subscribe</button>
"""


class Command(BaseCommand):
    help = "Create two demo pages: one with many issues, one clean."

    def handle(self, *args, **options):
        Page.objects.get_or_create(slug="needs-work", defaults={"title": "Needs work (demo)", "content": BAD})
        Page.objects.get_or_create(slug="accessible", defaults={"title": "Accessible (demo)", "content": GOOD})
        self.stdout.write(self.style.SUCCESS("Demo pages ready."))
