from django import forms

from .models import Page


class PageForm(forms.ModelForm):
    class Meta:
        model = Page
        fields = ["title", "slug", "content"]
        widgets = {"content": forms.Textarea(attrs={"rows": 18, "spellcheck": "false"})}
