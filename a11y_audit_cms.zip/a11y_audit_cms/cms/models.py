from django.db import models
from django.urls import reverse


class Page(models.Model):
    """A page in the mini CMS. `content` is the HTML body that gets audited."""
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    content = models.TextField(help_text="HTML for the page body.")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated_at"]

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("cms:page_detail", args=[self.slug])
