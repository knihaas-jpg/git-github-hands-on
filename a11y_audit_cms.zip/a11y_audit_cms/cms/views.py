from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render

from .forms import PageForm
from .models import Page


def page_list(request):
    return render(request, "cms/page_list.html", {"pages": Page.objects.all()})


def page_detail(request, slug):
    page = get_object_or_404(Page, slug=slug)
    return render(request, "cms/page_detail.html", {"page": page, "last_audit": page.audits.first()})


def page_create(request):
    form = PageForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        page = form.save()
        messages.success(request, "Page saved.")
        return redirect(page)
    return render(request, "cms/page_form.html", {"form": form, "heading": "New page"})


def page_edit(request, slug):
    page = get_object_or_404(Page, slug=slug)
    form = PageForm(request.POST or None, instance=page)
    if request.method == "POST" and form.is_valid():
        page = form.save()
        messages.success(request, "Page updated.")
        return redirect(page)
    return render(request, "cms/page_form.html", {"form": form, "heading": f"Edit: {page.title}"})
