import csv
from collections import defaultdict

from django.conf import settings
from django.contrib import messages
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from cms.models import Page

from .engine import KEYBOARD_CHECKLIST, FetchError, fetch_url
from .forms import AuditForm
from .models import AuditRun
from .services import run_audit


def dashboard(request):
    form = AuditForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        url, html = form.cleaned_data["url"], form.cleaned_data["html"]
        try:
            if url:
                html = fetch_url(url, allow_private=settings.AUDIT_ALLOW_PRIVATE_URLS)
                run = run_audit("url", url, html)
            else:
                run = run_audit("html", "Pasted HTML", html)
        except FetchError as exc:
            form.add_error(None, str(exc))
        else:
            return redirect("audit:run_detail", pk=run.pk)
    return render(request, "audit/dashboard.html", {"form": form, "recent": AuditRun.objects.all()[:5]})


@require_POST
def audit_page(request, slug):
    page = get_object_or_404(Page, slug=slug)
    run = run_audit("page", page.title, page.content, page=page)
    messages.success(request, "Audit complete.")
    return redirect("audit:run_detail", pk=run.pk)


def _annotated_lines(run):
    by_line, unplaced = defaultdict(list), []
    findings = list(run.findings.all())
    for f in findings:
        (by_line[f.line] if f.line else unplaced).append(f)
    rows = [{"no": i, "text": text, "findings": by_line.get(i, [])}
            for i, text in enumerate(run.source_html.splitlines(), 1)]
    return rows, unplaced, findings


def run_detail(request, pk):
    run = get_object_or_404(AuditRun, pk=pk)
    rows, unplaced, findings = _annotated_lines(run)
    return render(request, "audit/run_detail.html", {
        "run": run, "rows": rows, "unplaced": unplaced, "findings": findings,
        "checklist": KEYBOARD_CHECKLIST,
    })


def history(request):
    return render(request, "audit/history.html", {"runs": AuditRun.objects.select_related("page")})


def page_report(request, slug):
    page = get_object_or_404(Page, slug=slug)
    runs = list(page.audits.all())
    return render(request, "audit/page_report.html", {"page": page, "runs": runs, "latest": runs[0] if runs else None})


def _safe_cell(value):
    value = "" if value is None else str(value)
    return "'" + value if value[:1] in ("=", "+", "-", "@") else value


def export_csv(request, pk):
    run = get_object_or_404(AuditRun, pk=pk)
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="audit-{run.pk}.csv"'
    writer = csv.writer(response)
    writer.writerow(["line", "severity", "rule", "wcag", "message", "suggestion", "snippet"])
    for f in run.findings.all():
        writer.writerow([_safe_cell(x) for x in (f.line, f.severity, f.rule_id, f.wcag, f.message, f.suggestion, f.snippet)])
    return response


def export_html(request, pk):
    run = get_object_or_404(AuditRun, pk=pk)
    response = render(request, "audit/report_export.html", {"run": run, "findings": run.findings.all()})
    response["Content-Disposition"] = f'attachment; filename="audit-{run.pk}.html"'
    return response
