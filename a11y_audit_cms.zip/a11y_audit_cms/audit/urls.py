from django.urls import path

from . import views

app_name = "audit"
urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("history/", views.history, name="history"),
    path("audit/<int:pk>/", views.run_detail, name="run_detail"),
    path("audit/<int:pk>/export.csv", views.export_csv, name="export_csv"),
    path("audit/<int:pk>/export.html", views.export_html, name="export_html"),
    path("pages/<slug:slug>/audit/", views.audit_page, name="audit_page"),
    path("pages/<slug:slug>/report/", views.page_report, name="page_report"),
]
