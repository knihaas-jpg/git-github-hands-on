from django import forms


class AuditForm(forms.Form):
    url = forms.URLField(required=False, label="Page URL", assume_scheme="https",
                         help_text="A public web page, e.g. https://example.com")
    html = forms.CharField(required=False, label="Or paste HTML", widget=forms.Textarea(attrs={"rows": 8, "spellcheck": "false"}))

    def clean(self):
        data = super().clean()
        url, html = data.get("url"), (data.get("html") or "").strip()
        if bool(url) == bool(html):
            raise forms.ValidationError("Enter either a URL or some HTML, not both and not neither.")
        data["html"] = html
        return data
