import unittest

from audit.engine import FetchError, audit_html, fetch_url
from audit.engine import contrast as C


def rules(html):
    return {f.rule_id for f in audit_html(html).findings}


class ContrastTests(unittest.TestCase):
    def test_black_on_white_is_21(self):
        self.assertEqual(C.evaluate((0, 0, 0), (255, 255, 255)).ratio, 21.0)

    def test_777_on_white_fails_aa(self):
        res = C.evaluate(C.parse_color("#777"), (255, 255, 255))
        self.assertEqual(res.ratio, 4.48)
        self.assertFalse(res.passes_aa)

    def test_767676_on_white_passes_aa(self):
        self.assertTrue(C.evaluate(C.parse_color("#767676"), (255, 255, 255)).passes_aa)

    def test_large_text_threshold(self):
        res = C.evaluate(C.parse_color("#777"), (255, 255, 255), large=True)
        self.assertTrue(res.passes_aa)

    def test_parse_colors(self):
        self.assertEqual(C.parse_color("rgb(10, 20, 30)"), (10, 20, 30))
        self.assertEqual(C.parse_color("White"), (255, 255, 255))
        self.assertIsNone(C.parse_color("var(--x)"))

    def test_suggestion_meets_target(self):
        fix = C.parse_color(C.suggest_foreground((119, 119, 119), (255, 255, 255), 4.5))
        self.assertGreaterEqual(C.contrast_ratio(fix, (255, 255, 255)), 4.5)


class RuleTests(unittest.TestCase):
    def test_missing_alt(self):
        self.assertIn("img-alt-missing", rules('<img src="a.png">'))

    def test_empty_alt_is_ok_for_decorative(self):
        self.assertNotIn("img-alt-missing", rules('<img src="a.png" alt="">'))

    def test_filename_alt(self):
        self.assertIn("img-alt-filename", rules('<img src="a.png" alt="IMG_1234.jpg">'))

    def test_heading_skip_and_empty(self):
        r = rules("<h1>A</h1><h3>B</h3><h2></h2>")
        self.assertIn("heading-skipped", r)
        self.assertIn("heading-empty", r)

    def test_document_level_checks(self):
        r = rules("<html><head></head><body><p>Hi</p></body></html>")
        self.assertTrue({"html-lang-missing", "title-missing", "heading-no-h1", "skip-link-missing"} <= r)

    def test_fragment_skips_document_checks(self):
        self.assertNotIn("html-lang-missing", rules("<p>Hi</p>"))

    def test_generic_and_empty_links(self):
        r = rules('<a href="/x">click here</a><a href="/y"></a><a href="#">Go</a>')
        self.assertTrue({"link-generic-text", "link-no-name", "link-fake-href"} <= r)

    def test_form_labels(self):
        self.assertIn("form-label-missing", rules('<input type="text" placeholder="Name">'))
        self.assertNotIn("form-label-missing", rules('<label for="n">Name</label><input id="n">'))
        self.assertNotIn("form-label-missing", rules("<label>Name <input></label>"))

    def test_button_without_name(self):
        self.assertIn("button-no-name", rules("<button><svg></svg></button>"))
        self.assertNotIn("button-no-name", rules('<button aria-label="Close"></button>'))

    def test_inline_contrast(self):
        r = rules('<p style="color:#777">Low contrast</p>')
        self.assertIn("contrast-low", r)
        self.assertNotIn("contrast-low", rules('<p style="color:#000">Fine</p>'))

    def test_contrast_uses_ancestor_background(self):
        html = '<div style="background:#000"><p style="color:#222">Dark on dark</p></div>'
        self.assertIn("contrast-low", rules(html))

    def test_keyboard_rules(self):
        r = rules('<div onclick="x()">Go</div><span role="button">B</span>'
                  '<a onclick="x()">A</a><button tabindex="3" style="outline:none">Hi</button>')
        self.assertTrue({"click-not-keyboard", "role-not-focusable", "anchor-no-href",
                         "tabindex-positive", "focus-outline-removed"} <= r)

    def test_skip_link_present(self):
        html = '<html lang="en"><head><title>t</title></head><body><a href="#main">Skip to content</a><h1>x</h1></body></html>'
        self.assertNotIn("skip-link-missing", rules(html))

    def test_line_numbers_and_score(self):
        res = audit_html('<h1>T</h1>\n<img src="a.png">')
        self.assertEqual(res.findings[0].line, 2)
        self.assertEqual(res.score, 90)
        self.assertEqual(res.counts["error"], 1)

    def test_clean_page_scores_100(self):
        self.assertEqual(audit_html('<h1>Title</h1><p>Text</p>').score, 100)


class FetchTests(unittest.TestCase):
    def test_rejects_bad_scheme(self):
        with self.assertRaises(FetchError):
            fetch_url("ftp://example.com")

    def test_blocks_loopback(self):
        with self.assertRaises(FetchError):
            fetch_url("http://127.0.0.1:8000/")


if __name__ == "__main__":
    unittest.main()
