from unittest import mock

from django.test import TestCase
from django.urls import reverse

from audit.engine import FetchError
from audit.models import AuditRun
from cms.models import Page


class AuditViewTests(TestCase):
    def test_dashboard_loads(self):
        self.assertEqual(self.client.get(reverse("audit:dashboard")).status_code, 200)

    def test_form_requires_exactly_one_input(self):
        resp = self.client.post(reverse("audit:dashboard"), {"url": "", "html": ""})
        self.assertContains(resp, "either a URL or some HTML")
        self.assertEqual(AuditRun.objects.count(), 0)

    def test_audit_pasted_html_saves_run_and_findings(self):
        resp = self.client.post(reverse("audit:dashboard"), {"html": '<img src="a.png">'})
        run = AuditRun.objects.get()
        self.assertRedirects(resp, reverse("audit:run_detail", args=[run.pk]))
        self.assertEqual(run.error_count, 1)
        self.assertEqual(run.findings.get().rule_id, "img-alt-missing")

    @mock.patch("audit.views.fetch_url", return_value="<h1>Hi</h1><p>ok</p>")
    def test_audit_url(self, fetch):
        self.client.post(reverse("audit:dashboard"), {"url": "https://example.com"})
        run = AuditRun.objects.get()
        self.assertEqual((run.source_type, run.score), ("url", 100))

    @mock.patch("audit.views.fetch_url", side_effect=FetchError("That address is private."))
    def test_fetch_error_is_shown(self, fetch):
        resp = self.client.post(reverse("audit:dashboard"), {"url": "http://127.0.0.1"})
        self.assertContains(resp, "That address is private.")
        self.assertEqual(AuditRun.objects.count(), 0)

    def test_run_detail_shows_inline_finding_and_checklist(self):
        self.client.post(reverse("audit:dashboard"), {"html": '<h1>T</h1>\n<img src="a.png">'})
        run = AuditRun.objects.get()
        resp = self.client.get(reverse("audit:run_detail", args=[run.pk]))
        self.assertContains(resp, "Quick fix")
        self.assertContains(resp, 'id="L2"')
        self.assertContains(resp, "Keyboard navigation checklist")

    def test_html_in_source_is_escaped(self):
        self.client.post(reverse("audit:dashboard"), {"html": '<img src=x onerror="alert(1)">'})
        run = AuditRun.objects.get()
        resp = self.client.get(reverse("audit:run_detail", args=[run.pk]))
        self.assertNotContains(resp, '<img src=x onerror="alert(1)">')

    def test_history_lists_runs(self):
        self.client.post(reverse("audit:dashboard"), {"html": "<p>x</p>"})
        self.assertContains(self.client.get(reverse("audit:history")), "Pasted HTML")

    def test_csv_export_and_formula_guard(self):
        self.client.post(reverse("audit:dashboard"), {"html": '<a href="/x">click here</a>'})
        run = AuditRun.objects.get()
        resp = self.client.get(reverse("audit:export_csv", args=[run.pk]))
        self.assertEqual(resp["Content-Type"], "text/csv")
        self.assertIn("link-generic-text", resp.content.decode())

    def test_html_export_is_attachment(self):
        self.client.post(reverse("audit:dashboard"), {"html": "<p>x</p>"})
        run = AuditRun.objects.get()
        resp = self.client.get(reverse("audit:export_html", args=[run.pk]))
        self.assertIn("attachment", resp["Content-Disposition"])


class CmsAuditFlowTests(TestCase):
    def setUp(self):
        self.page = Page.objects.create(title="About", slug="about", content='<h1>About</h1><img src="t.png">')

    def test_audit_requires_post(self):
        self.assertEqual(self.client.get(reverse("audit:audit_page", args=["about"])).status_code, 405)

    def test_audit_page_links_run_to_page(self):
        self.client.post(reverse("audit:audit_page", args=["about"]))
        run = AuditRun.objects.get()
        self.assertEqual(run.page, self.page)
        self.assertEqual(run.source_type, "page")

    def test_page_report_shows_history(self):
        self.client.post(reverse("audit:audit_page", args=["about"]))
        self.client.post(reverse("audit:audit_page", args=["about"]))
        resp = self.client.get(reverse("audit:page_report", args=["about"]))
        self.assertEqual(len(resp.context["runs"]), 2)

    def test_deleting_page_keeps_history(self):
        self.client.post(reverse("audit:audit_page", args=["about"]))
        self.page.delete()
        self.assertEqual(AuditRun.objects.count(), 1)
        self.assertIsNone(AuditRun.objects.get().page)
