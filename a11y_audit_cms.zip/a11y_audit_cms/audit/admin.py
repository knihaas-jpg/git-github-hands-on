from django.contrib import admin

from .models import AuditRun, Finding


class FindingInline(admin.TabularInline):
    model = Finding
    extra = 0
    can_delete = False


@admin.register(AuditRun)
class AuditRunAdmin(admin.ModelAdmin):
    list_display = ("source_label", "source_type", "score", "error_count", "warning_count", "created_at")
    list_filter = ("source_type",)
    inlines = [FindingInline]
