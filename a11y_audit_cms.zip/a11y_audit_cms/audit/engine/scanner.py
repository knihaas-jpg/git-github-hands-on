"""Run all checks on HTML, and fetch HTML from a public URL safely."""
from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from . import checks

SEVERITY_WEIGHT = {checks.ERROR: 10, checks.WARNING: 4, checks.INFO: 1}


@dataclass
class AuditResult:
    findings: list
    score: int
    counts: dict


class FetchError(Exception):
    """Raised with a user-friendly message when a URL cannot be audited."""


def audit_html(html: str) -> AuditResult:
    soup = BeautifulSoup(html or "", "html.parser")
    is_document = soup.find("html") is not None
    findings = []
    findings += checks.check_document(soup, is_document)
    findings += checks.check_images(soup)
    findings += checks.check_headings(soup, is_document)
    findings += checks.check_links(soup)
    findings += checks.check_forms(soup)
    findings += checks.check_contrast(soup)
    findings += checks.check_keyboard(soup, is_document)
    findings += checks.check_misc(soup)
    findings.sort(key=lambda f: (f.line is None, f.line or 0))
    counts = {s: sum(1 for f in findings if f.severity == s) for s in SEVERITY_WEIGHT}
    penalty = sum(SEVERITY_WEIGHT[f.severity] for f in findings)
    return AuditResult(findings, max(0, 100 - penalty), counts)


def _ensure_public(host: str) -> None:
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        raise FetchError("Could not resolve that host name.")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            raise FetchError("That address is private. Only public web pages can be audited.")


def fetch_url(url: str, timeout: int = 10, max_bytes: int = 2_000_000,
              allow_private: bool = False, max_redirects: int = 5) -> str:
    """Download a page. Blocks private addresses (SSRF), re-checking every redirect."""
    current = url.strip()
    for _ in range(max_redirects + 1):
        parsed = urlparse(current)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise FetchError("Enter a valid http:// or https:// URL.")
        if not allow_private:
            _ensure_public(parsed.hostname)
        try:
            resp = requests.get(current, timeout=timeout, stream=True, allow_redirects=False,
                                headers={"User-Agent": "A11yAuditTool/1.0 (+student project)"})
        except requests.RequestException:
            raise FetchError("The page could not be downloaded (timeout or connection error).")
        if resp.is_redirect or resp.status_code in (301, 302, 303, 307, 308):
            location = resp.headers.get("Location")
            resp.close()
            if not location:
                raise FetchError("The server sent a bad redirect.")
            current = urljoin(current, location)
            continue
        if resp.status_code >= 400:
            resp.close()
            raise FetchError(f"The server answered with HTTP {resp.status_code}.")
        if "html" not in resp.headers.get("Content-Type", "").lower():
            resp.close()
            raise FetchError("That URL is not an HTML page.")
        data = b""
        for chunk in resp.iter_content(8192):
            data += chunk
            if len(data) > max_bytes:
                resp.close()
                raise FetchError("The page is too large to audit (over 2 MB).")
        return data.decode(resp.encoding or resp.apparent_encoding or "utf-8", errors="replace")
    raise FetchError("Too many redirects.")
