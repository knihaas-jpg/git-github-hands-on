"""Static accessibility checks. Each check takes a BeautifulSoup tree and returns Findings."""
from __future__ import annotations

import re
from dataclasses import dataclass

from . import contrast as C

ERROR, WARNING, INFO = "error", "warning", "info"


@dataclass
class Finding:
    rule_id: str
    severity: str
    message: str
    suggestion: str
    snippet: str = ""
    line: int | None = None
    wcag: str = ""


def _open_tag(tag) -> str:
    attrs = " ".join(
        f'{k}="{" ".join(v) if isinstance(v, list) else v}"' for k, v in tag.attrs.items()
    )
    return f"<{tag.name}{' ' + attrs if attrs else ''}>"[:200]


def _f(tag, rule_id, severity, message, suggestion, wcag=""):
    return Finding(rule_id, severity, message, suggestion, _open_tag(tag),
                   getattr(tag, "sourceline", None), wcag)


def _has_name(tag) -> bool:
    """True if a link/button exposes some accessible name."""
    for attr in ("aria-label", "aria-labelledby", "title"):
        if (tag.get(attr) or "").strip():
            return True
    if tag.get_text(strip=True):
        return True
    return any((img.get("alt") or "").strip() for img in tag.find_all("img"))


# --- document level ---------------------------------------------------------

def check_document(soup, is_document):
    out = []
    if not is_document:
        return out
    html = soup.find("html")
    if not (html.get("lang") or "").strip():
        out.append(_f(html, "html-lang-missing", ERROR,
                      "The <html> element has no lang attribute.",
                      'Add the page language, e.g. <html lang="en">.', "3.1.1"))
    if not soup.title or not soup.title.get_text(strip=True):
        out.append(Finding("title-missing", ERROR, "The page has no <title> or it is empty.",
                           "Add a short, unique <title> that describes the page.", "", None, "2.4.2"))
    return out


# --- images -----------------------------------------------------------------

_FILENAME_ALT = re.compile(r"\.(png|jpe?g|gif|svg|webp|bmp)$|^(img|image|photo|dsc|screenshot)[-_ ]?\d*$", re.I)


def check_images(soup):
    out = []
    for img in soup.find_all("img"):
        if not img.has_attr("alt"):
            out.append(_f(img, "img-alt-missing", ERROR, "Image has no alt attribute.",
                          'Add alt text describing the image, or alt="" if it is purely decorative.', "1.1.1"))
            continue
        alt = (img.get("alt") or "").strip()
        if alt and _FILENAME_ALT.search(alt):
            out.append(_f(img, "img-alt-filename", WARNING, "Alt text looks like a file name.",
                          "Replace it with a short description of what the image conveys.", "1.1.1"))
        elif len(alt) > 125:
            out.append(_f(img, "img-alt-long", INFO, "Alt text is very long.",
                          "Keep alt under about 125 characters; put detail in the surrounding text or a caption.", "1.1.1"))
    return out


# --- headings ---------------------------------------------------------------

def check_headings(soup, is_document):
    out = []
    headings = soup.find_all(re.compile(r"^h[1-6]$"))
    h1s = [h for h in headings if h.name == "h1"]
    if is_document and not h1s:
        out.append(Finding("heading-no-h1", WARNING, "The page has no <h1>.",
                           "Add one <h1> that names the page's main topic.", "", None, "2.4.6"))
    for extra in h1s[1:]:
        out.append(_f(extra, "heading-multiple-h1", WARNING, "More than one <h1> on the page.",
                      "Use a single <h1> and make the others <h2> or lower.", "1.3.1"))
    prev = None
    for h in headings:
        level = int(h.name[1])
        if not h.get_text(strip=True):
            out.append(_f(h, "heading-empty", ERROR, "Heading is empty.",
                          "Add heading text or remove the element.", "2.4.6"))
        if prev is not None and level > prev + 1:
            out.append(_f(h, "heading-skipped", WARNING,
                          f"Heading level jumps from h{prev} to h{level}.",
                          f"Use h{prev + 1} here, then style it with CSS if needed.", "1.3.1"))
        prev = level
    return out


# --- links ------------------------------------------------------------------

_GENERIC = {"click here", "here", "read more", "more", "learn more", "link", "this link", "details"}


def check_links(soup):
    out = []
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        text = " ".join(a.get_text().split()).lower().strip(" .:>»")
        if not _has_name(a):
            out.append(_f(a, "link-no-name", ERROR, "Link has no accessible name.",
                          "Add descriptive link text or an aria-label.", "2.4.4"))
        elif text in _GENERIC and not (a.get("aria-label") or "").strip():
            out.append(_f(a, "link-generic-text", WARNING, f'Link text "{text}" is not descriptive.',
                          "Say where the link goes, e.g. \"Read the 2026 accessibility report\".", "2.4.4"))
        if href in ("#", "") or href.lower().startswith("javascript:"):
            out.append(_f(a, "link-fake-href", WARNING, "Link has a placeholder href.",
                          "Use a <button> for actions, or point the link at a real URL.", "4.1.2"))
    return out


# --- forms and buttons ------------------------------------------------------

_SKIP_INPUT = {"hidden", "submit", "button", "reset", "image"}


def _has_label(soup, el) -> bool:
    for attr in ("aria-label", "aria-labelledby", "title"):
        if (el.get(attr) or "").strip():
            return True
    if el.find_parent("label"):
        return True
    el_id = el.get("id")
    return bool(el_id and soup.find("label", attrs={"for": el_id}))


def check_forms(soup):
    out = []
    for el in soup.find_all(["input", "select", "textarea"]):
        itype = (el.get("type") or "text").lower() if el.name == "input" else el.name
        if itype == "image":
            if not (el.get("alt") or "").strip():
                out.append(_f(el, "input-image-alt", ERROR, "Image button has no alt text.",
                              "Add alt text that says what the button does.", "1.1.1"))
            continue
        if itype in _SKIP_INPUT:
            continue
        if not _has_label(soup, el):
            hint = " A placeholder is not a substitute for a label." if el.get("placeholder") else ""
            out.append(_f(el, "form-label-missing", ERROR, "Form field has no label." + hint,
                          'Add <label for="id"> tied to this field, or an aria-label.', "3.3.2"))
    for b in soup.find_all("button"):
        if not _has_name(b):
            out.append(_f(b, "button-no-name", ERROR, "Button has no accessible name.",
                          "Add visible text or an aria-label (important for icon-only buttons).", "4.1.2"))
    return out


# --- colour contrast (inline styles) ----------------------------------------

def _background_for(tag):
    node = tag
    while node is not None and getattr(node, "name", None):
        st = C.parse_inline_style(node.get("style", ""))
        bg = C.parse_color(st.get("background-color") or st.get("background"))
        if bg:
            return bg
        node = node.parent
    return (255, 255, 255)  # assume a white page background


def check_contrast(soup):
    out = []
    for tag in soup.find_all(style=True):
        if not any(s.strip() for s in tag.find_all(string=True, recursive=False)):
            continue
        st = C.parse_inline_style(tag["style"])
        fg = C.parse_color(st.get("color"))
        if not fg:
            continue
        bg = _background_for(tag)
        large = C.is_large_text(C.parse_font_size(st.get("font-size")), C.is_bold(st.get("font-weight")))
        res = C.evaluate(fg, bg, large)
        if not res.passes_aa:
            fix = C.suggest_foreground(fg, bg, res.required_aa)
            kind = "large text" if large else "normal text"
            out.append(_f(tag, "contrast-low", ERROR,
                          f"Contrast is {res.ratio}:1 but WCAG AA needs {res.required_aa}:1 for {kind}.",
                          f"Change the text colour to {fix} or adjust the background.", "1.4.3"))
    return out


# --- keyboard ---------------------------------------------------------------

_NON_INTERACTIVE = ["div", "span", "li", "p", "img", "td", "section", "article"]
_WIDGET_ROLES = {"button", "link", "checkbox", "tab", "menuitem", "switch", "radio"}
_INTERACTIVE = ["a", "button", "input", "select", "textarea"]


def check_keyboard(soup, is_document):
    out = []
    for el in soup.find_all(attrs={"tabindex": True}):
        try:
            value = int(str(el["tabindex"]).strip())
        except ValueError:
            continue
        if value > 0:
            out.append(_f(el, "tabindex-positive", WARNING, f"tabindex=\"{value}\" overrides natural tab order.",
                          'Use tabindex="0" or remove it, and fix the order in the HTML source.', "2.4.3"))
    for el in soup.find_all(_NON_INTERACTIVE):
        if el.has_attr("onclick") and not el.get("role") and not el.has_attr("tabindex"):
            out.append(_f(el, "click-not-keyboard", ERROR, f"<{el.name}> has a click handler but cannot be focused.",
                          "Use a <button> (or <a href>) instead of a clickable <" + el.name + ">.", "2.1.1"))
    for el in soup.find_all(attrs={"role": True}):
        if (el.get("role") or "").lower() in _WIDGET_ROLES and el.name not in _INTERACTIVE and not el.has_attr("tabindex"):
            out.append(_f(el, "role-not-focusable", ERROR, f'role="{el["role"]}" element is not keyboard focusable.',
                          'Add tabindex="0" and Enter/Space key handlers, or use a native element.', "2.1.1"))
    for a in soup.find_all("a"):
        if not a.has_attr("href") and a.has_attr("onclick") and not a.get("role"):
            out.append(_f(a, "anchor-no-href", WARNING, "<a> has a click handler but no href, so it is skipped by Tab.",
                          "Use a <button> for actions.", "2.1.1"))
    for el in soup.find_all(_INTERACTIVE, style=True):
        st = C.parse_inline_style(el["style"])
        if st.get("outline") in ("none", "0") or st.get("outline-style") == "none":
            out.append(_f(el, "focus-outline-removed", WARNING, "Focus outline is removed.",
                          "Keep a visible focus style, e.g. :focus-visible { outline: 3px solid #1a56db; }", "2.4.7"))
    if is_document:
        links = soup.find_all("a", href=True)[:5]
        if not any(l["href"].startswith("#") and len(l["href"]) > 1 and "skip" in l.get_text().lower() for l in links):
            out.append(Finding("skip-link-missing", INFO, "No 'skip to main content' link found near the top.",
                               'Add <a href="#main" class="skip-link">Skip to main content</a> as the first link.',
                               "", None, "2.4.1"))
    return out


# --- misc structure ---------------------------------------------------------

def check_misc(soup):
    out = []
    for fr in soup.find_all("iframe"):
        if not (fr.get("title") or "").strip():
            out.append(_f(fr, "iframe-title-missing", ERROR, "<iframe> has no title.",
                          "Add a title that describes the embedded content.", "4.1.2"))
    for t in soup.find_all("table"):
        if not t.find("th"):
            out.append(_f(t, "table-no-headers", INFO, "Table has no header cells.",
                          "Use <th> (with scope) for header cells, or use a list if it is layout only.", "1.3.1"))
    return out
