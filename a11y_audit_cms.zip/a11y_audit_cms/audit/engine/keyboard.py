"""Manual keyboard-navigation checklist (automation cannot prove these)."""

KEYBOARD_CHECKLIST = [
    ("tab-reach", "Every link, button and form field can be reached with the Tab key."),
    ("tab-order", "Tab order follows the visual and reading order of the page."),
    ("focus-visible", "A clearly visible focus indicator appears on every focused element."),
    ("no-trap", "Focus is never trapped; you can always Tab or Esc out of widgets and dialogs."),
    ("skip-link", "A skip link appears on first Tab and moves focus to the main content."),
    ("activate", "Links work with Enter; buttons work with Enter and Space."),
    ("menus", "Menus, tabs and dropdowns can be used with arrow keys, Enter and Esc."),
    ("forms", "Every form can be completed and submitted using only the keyboard."),
    ("dialogs", "Opening a dialog moves focus into it; closing it returns focus to the trigger."),
    ("hover-only", "No content or control appears only on mouse hover."),
]
