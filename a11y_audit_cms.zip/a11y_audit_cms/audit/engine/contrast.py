"""WCAG 2.x colour-contrast helpers (WCAG 1.4.3). Pure Python, no Django."""
from __future__ import annotations

import re
from dataclasses import dataclass

NAMED = {
    "black": (0, 0, 0), "white": (255, 255, 255), "red": (255, 0, 0),
    "green": (0, 128, 0), "blue": (0, 0, 255), "gray": (128, 128, 128),
    "grey": (128, 128, 128), "silver": (192, 192, 192), "yellow": (255, 255, 0),
    "orange": (255, 165, 0), "purple": (128, 0, 128), "navy": (0, 0, 128),
    "maroon": (128, 0, 0), "teal": (0, 128, 128), "lightgray": (211, 211, 211),
    "lightgrey": (211, 211, 211), "darkgray": (169, 169, 169),
}
_HEX = re.compile(r"^#([0-9a-f]{3}|[0-9a-f]{6})$", re.I)
_RGB = re.compile(r"^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$", re.I)


@dataclass(frozen=True)
class ContrastResult:
    ratio: float
    required_aa: float
    passes_aa: bool
    passes_aaa: bool


def parse_color(value: str | None):
    """Return (r, g, b) or None if the value is not a simple colour."""
    if not value:
        return None
    v = value.strip().lower()
    if v in NAMED:
        return NAMED[v]
    m = _HEX.match(v)
    if m:
        h = m.group(1)
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    m = _RGB.match(v)
    if m:
        rgb = tuple(int(x) for x in m.groups())
        if max(rgb) <= 255:
            return rgb
    return None


def to_hex(rgb) -> str:
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def _channel(c: int) -> float:
    s = c / 255
    return s / 12.92 if s <= 0.03928 else ((s + 0.055) / 1.055) ** 2.4


def relative_luminance(rgb) -> float:
    r, g, b = (_channel(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast_ratio(fg, bg) -> float:
    l1, l2 = relative_luminance(fg), relative_luminance(bg)
    return (max(l1, l2) + 0.05) / (min(l1, l2) + 0.05)


def is_large_text(size_px: float, bold: bool) -> bool:
    """WCAG large text: >= 24px, or >= 18.66px (14pt) when bold."""
    return size_px >= 24 or (bold and size_px >= 18.66)


def evaluate(fg, bg, large: bool = False) -> ContrastResult:
    ratio = contrast_ratio(fg, bg)
    aa = 3.0 if large else 4.5
    aaa = 4.5 if large else 7.0
    return ContrastResult(round(ratio, 2), aa, ratio >= aa, ratio >= aaa)


def suggest_foreground(fg, bg, target: float = 4.5) -> str:
    """Nudge fg toward black or white (whichever suits bg) until it meets target."""
    end = (0, 0, 0) if contrast_ratio((0, 0, 0), bg) >= contrast_ratio((255, 255, 255), bg) else (255, 255, 255)
    for step in range(0, 21):
        t = step / 20
        candidate = tuple(round(f + (e - f) * t) for f, e in zip(fg, end))
        if contrast_ratio(candidate, bg) >= target:
            return to_hex(candidate)
    return to_hex(end)


def parse_inline_style(style: str) -> dict:
    props = {}
    for part in (style or "").split(";"):
        if ":" in part:
            k, v = part.split(":", 1)
            props[k.strip().lower()] = v.strip().lower()
    return props


def parse_font_size(value: str | None, default: float = 16.0) -> float:
    if not value:
        return default
    m = re.match(r"^([\d.]+)\s*(px|pt|rem|em)$", value.strip())
    if not m:
        return default
    n, unit = float(m.group(1)), m.group(2)
    return n * {"px": 1, "pt": 96 / 72, "rem": 16, "em": 16}[unit]


def is_bold(value: str | None) -> bool:
    if not value:
        return False
    v = value.strip()
    return v in ("bold", "bolder") or (v.isdigit() and int(v) >= 700)
