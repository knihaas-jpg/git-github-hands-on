from django.db import transaction

from .engine import audit_html
from .models import AuditRun, Finding


def run_audit(source_type: str, label: str, html: str, page=None) -> AuditRun:
    """Audit `html`, save the run plus its findings, and return the AuditRun."""
    result = audit_html(html)
    with transaction.atomic():
        run = AuditRun.objects.create(
            page=page, source_type=source_type, source_label=label[:500], source_html=html,
            score=result.score, error_count=result.counts["error"],
            warning_count=result.counts["warning"], info_count=result.counts["info"],
        )
        Finding.objects.bulk_create(
            Finding(run=run, rule_id=f.rule_id, severity=f.severity, message=f.message,
                    suggestion=f.suggestion, snippet=f.snippet, line=f.line, wcag=f.wcag)
            for f in result.findings
        )
    return run
