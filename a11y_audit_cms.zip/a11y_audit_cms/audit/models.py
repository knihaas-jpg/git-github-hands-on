from django.db import models


class AuditRun(models.Model):
    """One saved audit. Keeps a copy of the audited HTML so reports stay reproducible."""
    SOURCE_CHOICES = [("page", "CMS page"), ("url", "URL"), ("html", "Pasted HTML")]

    page = models.ForeignKey("cms.Page", null=True, blank=True, on_delete=models.SET_NULL, related_name="audits")
    source_type = models.CharField(max_length=10, choices=SOURCE_CHOICES)
    source_label = models.CharField(max_length=500)
    source_html = models.TextField()
    score = models.PositiveSmallIntegerField()
    error_count = models.PositiveIntegerField(default=0)
    warning_count = models.PositiveIntegerField(default=0)
    info_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]

    def __str__(self):
        return f"{self.source_label} ({self.score}/100)"

    @property
    def total_findings(self):
        return self.error_count + self.warning_count + self.info_count


class Finding(models.Model):
    run = models.ForeignKey(AuditRun, on_delete=models.CASCADE, related_name="findings")
    rule_id = models.CharField(max_length=50)
    severity = models.CharField(max_length=10)
    message = models.TextField()
    suggestion = models.TextField()
    snippet = models.TextField(blank=True)
    line = models.PositiveIntegerField(null=True, blank=True)
    wcag = models.CharField(max_length=10, blank=True)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return f"{self.rule_id} (line {self.line})"
