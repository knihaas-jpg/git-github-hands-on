# Accessibility Audit Tool for a Mini CMS

A Django web app that audits pages for common WCAG 2.1 accessibility problems, shows findings inline next to the HTML, suggests quick fixes, and keeps an audit history per page.

## The problem

Small CMS-driven sites are edited by non-experts who publish images without alt text, skip heading levels, write "click here" links and pick low-contrast colours. Enterprise scanners are heavy, and browser extensions leave no history. Editors need a lightweight check that lives next to their content and tells them exactly what to fix.

## Features (from the approved proposal)

| Must-have | Where |
|---|---|
| URL / HTML scanner (alt text, headings, links, forms, buttons) | `audit/engine/checks.py` |
| Inline findings with quick-fix suggestions | run detail page |
| Colour contrast checker (WCAG 1.4.3, AA/AAA, large text) | `audit/engine/contrast.py` |
| Keyboard navigation checks plus manual checklist | `checks.check_keyboard`, `engine/keyboard.py` |
| Page-wise reports | `/pages/<slug>/report/` |
| Audit history in SQLite | `AuditRun` and `Finding` models |
| Stretch: CSV and HTML report downloads | `/audit/<id>/export.csv` and `.html` |
| Stretch: tests and GitHub Actions | `audit/tests`, `cms/tests`, `.github/workflows/ci.yml` |

The audit engine (`audit/engine/`) has no Django imports, so it can later be packaged as a reusable module or a Wagtail-compatible package.

## Setup

```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py makemigrations cms audit
python manage.py migrate
python manage.py seed_demo          # optional: two demo pages
python manage.py createsuperuser    # optional: for /admin/
python manage.py runserver
```

Open http://127.0.0.1:8000/. To audit a page running on your own machine, start the server with `AUDIT_ALLOW_PRIVATE_URLS=1`.

## Run the tests

```bash
python manage.py test
coverage run --source=audit,cms manage.py test && coverage report
```

## Rules checked

| Rule id | Severity | WCAG |
|---|---|---|
| img-alt-missing / img-alt-filename / img-alt-long | error / warning / info | 1.1.1 |
| heading-no-h1 / heading-multiple-h1 / heading-skipped / heading-empty | warning / warning / warning / error | 1.3.1, 2.4.6 |
| link-no-name / link-generic-text / link-fake-href | error / warning / warning | 2.4.4, 4.1.2 |
| form-label-missing / input-image-alt / button-no-name | error | 3.3.2, 1.1.1, 4.1.2 |
| contrast-low | error | 1.4.3 |
| tabindex-positive / click-not-keyboard / role-not-focusable / anchor-no-href / focus-outline-removed / skip-link-missing | mixed | 2.1.1, 2.4.1, 2.4.3, 2.4.7 |
| html-lang-missing / title-missing | error | 3.1.1, 2.4.2 |
| iframe-title-missing / table-no-headers | error / info | 4.1.2, 1.3.1 |

Score = 100 minus 10 per error, 4 per warning, 1 per note (minimum 0).

## Security notes

- URL fetching blocks private, loopback and link-local addresses, re-checks every redirect, and caps size at 2 MB.
- Audited HTML is always displayed escaped, never rendered.
- CSV export neutralises formula-injection prefixes.

## Known limitations

- Static analysis only: no JavaScript execution, so dynamically injected content is not seen.
- Contrast is checked only for inline `style` attributes (not `<style>` blocks or external CSS).
- Missing background colour is assumed to be white.
- Automated checks cannot prove an accessible experience; the keyboard checklist covers what a human must test.

## Roadmap

1. Parse `<style>` blocks and linked CSS for contrast and focus styles.
2. Headless-browser mode (Playwright) for rendered pages and computed styles.
3. Package `audit.engine` for PyPI and a Wagtail panel.
4. Audit-on-save hook and score trend charts.
5. More rules: ARIA validity, landmark regions, link-purpose in context.

## Pros and cons

**Pros:** lightweight, self-hosted, explains each fix, keeps history, no external services.
**Cons:** fewer rules than axe-core or WAVE, static HTML only, scoring is a simple heuristic.
