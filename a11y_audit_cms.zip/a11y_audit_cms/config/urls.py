from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("pages/", include("cms.urls")),
    path("", include("audit.urls")),
]
