// Progressive enhancement only: the pages work without JavaScript.
document.addEventListener("DOMContentLoaded", function () {
  var toggle = document.getElementById("only-findings");
  var source = document.getElementById("source");
  if (toggle && source) {
    toggle.addEventListener("change", function () {
      source.classList.toggle("only-findings", toggle.checked);
    });
  }

  var boxes = document.querySelectorAll("input[data-check]");
  var progress = document.getElementById("kbd-progress");
  if (boxes.length) {
    var runId = document.body.querySelector("[data-run-id]");
    var key = "a11y-kbd-" + (runId ? runId.getAttribute("data-run-id") : "x");
    var saved = {};
    try { saved = JSON.parse(localStorage.getItem(key) || "{}"); } catch (e) { saved = {}; }
    var update = function () {
      var done = 0;
      boxes.forEach(function (b) { if (b.checked) { done += 1; } saved[b.id] = b.checked; });
      if (progress) { progress.textContent = done + " of " + boxes.length + " checks done"; }
      try { localStorage.setItem(key, JSON.stringify(saved)); } catch (e) { /* storage unavailable */ }
    };
    boxes.forEach(function (b) { b.checked = !!saved[b.id]; b.addEventListener("change", update); });
    update();
  }
});
